﻿389,100
390,Allocation Calculation
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,4
7,Year
270,0
274,
275,14
[Year].MEMBERS
281,0
282,
7,Month
270,0
274,
275,15
[Month].MEMBERS
281,0
282,
7,Version
270,0
274,
275,17
[Version].MEMBERS
281,0
282,
7,Allocation List
270,0
274,
275,25
[Allocation List].MEMBERS
281,0
282,
360,1
7,Allocation Calculation
270,10
Source Entity
Source Account
Allocation Amount
Exclude Entity
Allocation Driver
Driver
Total Driver
Ratio
Allocated Amount
Credit Amount
274,
275,
281,0
282,
371,1
7,organization
270,0
274,Caption_Base
275,22
[organization].MEMBERS
281,0
282,
373,4
1
3
1
2
372,0
372,00
384,0
385,0
377,4
122
186
1004
808
378,0
382,255
379,6
0
0
0
0
0
0
11,20120209021820
381,0
