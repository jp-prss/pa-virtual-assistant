﻿389,100
390,"High Level PL Report"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,4
7,organization
6,Workflow
7,Currency Calc
6,Default
7,Year
6,Default
7,Version
6,Current
360,1
7,Month
6,YQ
371,1
7,Account
6,High Level PL Report
373,4
1,Total Company
1,Local
2,Y2
1,Version 1
372,1
372,11
384,1
385,1
377,4
460
358
1773
931
378,0
382,255
379,6
0
0
0
0
0
0
11,20140523155129
381,0
