﻿389,100
390,"Opex Year Over Year"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,organization
6,Workflow
7,Currency Calc
6,Default
7,Version
6,Budget Target
7,Month
6,Y
360,1
7,Year
6,Default
371,1
7,Account
6,OpEx
373,4
1,Total Company
1,Local
1,Version 1
1,Year
372,0
372,00
384,0
385,0
377,4
216
715
1682
1337
378,0
382,255
379,6
0
0
0
0
0
0
11,20151202194416
381,0
