﻿389,100
390,"Default"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,4
7,Year
6,Default
7,Currency Calc
6,All Members
7,Organization Reporting
6,Default
7,Version
6,Current
360,1
7,Month
6,M
371,1
7,Account
6,Default
373,4
2,Y2
1,Local
1,Total Company
1,Version 1
372,0
372,00
384,0
385,0
377,4
754
752
1739
1283
378,0
382,255
379,6
0
0
0
0
0
0
11,20130924004149
381,0
