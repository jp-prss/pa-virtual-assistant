﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,4
7,Plant
270,0
274,
275,15
[Plant].MEMBERS
281,0
282,
7,Version
6,All Members
7,Year
6,All Members
7,Month
6,All Members
360,1
7,product
270,0
274,Caption_Default
275,17
[Product].MEMBERS
281,0
282,
371,1
7,Rate Measure
270,0
274,
275,22
[Rate Measure].MEMBERS
281,0
282,
373,4
5,Plant A
1,Version 1
2,Y2
3,Jan
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20140505023638
381,0
