﻿389,100
390,"Average BOM by Product"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,4
7,Version
6,Default
7,Year
6,Default
7,Rate Measure
6,Avg Local BOM
7,Month
6,All Members
360,1
7,product
6,Phones
371,1
7,Plant
6,default
373,4
10,Actual
2,Y2
1,Average Local BOM
1,Year
372,0
372,01
384,0
385,1
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20140505023548
381,0
