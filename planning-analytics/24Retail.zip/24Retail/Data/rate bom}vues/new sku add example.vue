﻿389,100
390,"New SKU Add example"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,0
375,c:0.00
374,3
7,Version
6,Default
7,Year
6,All Members
7,Month
6,All Members
360,1
7,Plant
6,Plants
371,2
7,product
6,New
7,Rate Measure
6,Default
373,3
1,Version 1
2,Y2
1,Year
372,1
372,11
384,1
385,1
377,4
-2
36
1606
916
378,0
382,255
379,6
0
0
0
0
0
0
11,20140506221154
381,0
