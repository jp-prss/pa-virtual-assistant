﻿389,100
390,"Impact Analysis"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,3
7,Metrics
270,14
4999
5999
GM
6099
6199
6299
6399
6499
6599
TE
NP
6699
NPAA
Statistics
274,Caption_Default
275,
281,1
282,
7,organization
270,15
Total Company
100
101
102
103
200
201
202
300
301
302
400
401
402
403
274,Caption_Base
275,
281,0
282,
7,Year
270,3
Y1
Y2
Y3
274,Caption_Default
275,
281,0
282,
360,1
7,Metrics Indicators
270,20
Status
Trend
Actual
Target
Tolerance
Variance
Variance Percent
Score
Score Change
Actual Change Percent
Status_1_Count
Status_0_Count
Status_-1_Count
Status_Incomplete_Count
Forecast Status
Forecast Trend
Forecast
Forecast Variance
Forecast Variance %
Forecast Score
274,
275,
281,0
282,
371,1
7,Month
6,Default
373,3
11,NP
1,Total Company
2,Y2
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20190930201925
381,0
32,6
null\n
