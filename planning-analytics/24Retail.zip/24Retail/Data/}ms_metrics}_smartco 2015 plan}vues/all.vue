﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,}MS_Metrics}_Smartco 2015 Plan
6,All Members
7,organization
6,All Members
7,Year
6,All Members
7,Month
6,All Members
7,Metrics Indicators
6,All Members
360,0
371,0
373,5
1
1,Total Company
1,Y1
1,Year
1,Status
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20130922025705
381,0
