﻿389,100
390,"z_TI_cube Task Workflow reset Status"
370,0
361,0
362,0
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,1
7,Task
6,z_TI_cube Task Workflow reset Status
360,1
7,Task Workflow Measure
6,z_TI_cube Task Workflow reset Status
371,1
7,organization
6,z_TI_cube Task Workflow reset Status
373,1
1,All Tasks
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,3
0
0
0
11,20130809171211
381,1
