﻿389,100
390,"Task Workflow"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,b:0.#########G|0|
374,1
7,organization
6,Default
360,1
7,Task Workflow Measure
270,5
Status
Due Date
Date Completed
Complete
Commentary
274,
275,
281,0
282,
371,1
7,Task
6,All Members
373,1
3,101
372,0
372,00
384,0
385,0
377,4
580
238
1735
769
378,0
382,255
379,3
0
0
0
11,20130809135705
381,0
