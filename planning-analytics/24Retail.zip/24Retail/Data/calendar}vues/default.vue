﻿389,100
390,"Default"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,b:0.#########G|0|
374,0
360,1
7,String
6,Default
371,1
7,Calendar
270,14
Current Month
Current Quarter
Current Year
Current Version
Compare Against
Fcst Month
Model Version
Base Directory
Data Directory
SPSS Directory
Directory Separator
Log Directory
SPSS Modeler Install Directory
Concert Reset Date
274,Caption_Default
275,
281,0
282,
373,0
372,0
372,00
384,0
385,0
377,4
256
44
1418
675
378,0
382,255
379,2
0
0
11,20140612025948
381,0
