﻿389,100
390,"DetailCOGSdrillView"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,6
7,Version
270,1
Version 1
274,Caption_Default
275,
281,0
282,
7,Channel
270,1
Channel Total
274,
275,
281,0
282,
7,Month
270,1
Mar
274,
275,
281,0
282,
7,organization
270,1
Total Company
274,
275,
281,0
282,
7,Year
270,1
Y2
274,Caption_Default
275,
281,0
282,
7,product
270,12
20000
21000
21001
21002
21003
21004
22000
22001
22002
22003
23000
23001
274,Caption_Default
275,
281,0
282,
360,0
371,1
7,Supply Chain Measures
270,9
Units Sold
Total Cost of Goods Sold - Regional
Direct Costs
Direct Material
Raw Material
Packaging Material
Pallets
Direct Labor
Indirect Costs
274,
275,
281,0
282,
373,6
1,Version 1
1,Channel Total
1,Mar
1,Total Company
1,Y2
1,20000
372,0
372,01
384,0
385,1
377,4
48
36
1631
916
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20140507065007
381,0
