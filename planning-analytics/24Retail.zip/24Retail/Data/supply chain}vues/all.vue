﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,product
6,All Members
7,Month
6,All Members
7,Year
6,All Members
7,Supply Chain Measures
270,0
274,
275,31
[Supply Chain Measures].MEMBERS
281,0
282,
7,Version
6,All Members
360,1
7,Channel
6,All Members
371,1
7,organization
6,All Members
373,5
1,Product Total
1,Year
1,Y1
1,Total Cost of Goods Sold - Regional
1,Version 1
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20140505023352
381,0
