﻿389,100
390,"Source"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,0
360,1
7,}Cubes
6,}PMTA_Temp_}MI_Revenue Metrics
371,1
7,}CubeAttributes
270,7
Image Type
Opacity
Image Layout
HorizontalPosition
VerticalPosition
Image Aspect Ratio
Metrics Control Version
274,
275,
281,0
282,
373,0
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,2
0
0
11,20140113221144
381,1
