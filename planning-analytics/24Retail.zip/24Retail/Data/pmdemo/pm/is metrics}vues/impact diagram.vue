﻿389,100
390,"Impact Diagram"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,3
7,organization
6,All Members
7,Year
6,All Members
7,Month
6,All Members
360,1
7,IS Metric Indicators
270,0
274,Caption_Default
275,30
[IS Metric Indicators].MEMBERS
281,0
282,
371,1
7,IS Metrics
270,1
NP
274,Caption_Default
275,
281,0
282,
373,3
1,Total Company
2,Y2
1,Year
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20130801143452
381,0
