﻿389,100
390,"Revenue Analysis Chart"
370,0
361,0
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,organization
6,Workflow
7,Revenue
6,Default
7,Channel
6,Default
7,Year
6,Default
7,Version
6,Current
360,1
7,Month
6,Q
371,1
7,product
6,Product Revenue Chart
373,5
3,101
2,Units Sold
1,Channel Total
2,Y2
1,Version 1
372,0
372,00
384,0
385,0
377,4
870
1009
2336
1631
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20151201200530
381,0
