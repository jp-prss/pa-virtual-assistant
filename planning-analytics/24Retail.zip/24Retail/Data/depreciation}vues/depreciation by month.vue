﻿389,100
390,"Depreciation by Month"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,organization
6,Workflow
7,Year
6,Default
7,Version
6,Current
7,Depreciation
6,Total Depreciation
360,1
7,Asset Types
6,Asset Type
371,1
7,Month
6,M
373,4
3,101
2,Y2
1,Version 1
1,Total Depreciation
372,0
372,00
384,0
385,0
377,4
1778
495
2735
1117
378,0
382,255
379,6
0
0
0
0
0
0
11,20151117003034
381,0
