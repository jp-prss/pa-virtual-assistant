﻿389,100
390,All
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,organization
6,All Members
7,Asset Types
6,All Members
7,Year
6,All Members
7,Version
6,All Members
360,1
7,Month
6,All Members
371,1
7,Depreciation
6,All Members
373,4
1
1
1
1
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20111201212716
381,0
