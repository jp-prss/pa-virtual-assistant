﻿389,100
390,"Analysis_1627d785-433f-4e5a-89bd-26f39a90e7af_[}tp_tasks}1627d785-433f-4e5a-89bd-26f39a90e7af].[101]"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,4
7,Year
6,Default
7,organization
6,Workflow
7,Currency Calc
270,0
274,
275,23
[Currency Calc].MEMBERS
281,0
282,
7,Version
6,Current
360,1
7,Month
6,QY
371,1
7,Account
270,23
4999
5999
GM
6099
6199
6299
6399
6499
6599
TE
NP
6699
NPAA
Statistics
Allocation Methods
Square Footage
Server Space
Metrics
Rev per FTE
Cost per FTE
EPS
Shares
FTE
274,Caption_Default
275,
281,0
282,
373,4
2,Y2
1,Total Company
1,Local
1,Version 1
372,0
372,00
384,0
385,0
377,4
-6
36
1690
1062
378,0
382,255
379,6
0
0
0
0
0
0
11,20140619035051
381,0
