﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,3
7,Metrics
6,All Members
7,}MI_Metrics_I
6,All Members
7,}MI_Metrics_D
6,All Members
360,0
371,0
373,3
1,Statistics
1,1
1,Impacting Metric
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,3
0
0
0
11,20130918015537
381,0
